import os
import numpy as np
import holoviews as hv
from holoviews import opts
from bokeh.io import show
# 使用 Bokeh 后端
hv.extension('bokeh')

# 设置保存路径
save_path = os.path.join(os.getcwd(), 'chord_diagram2.html')

# 准备数据
matrix = np.array([
    [0, 0.0112, 0.0113, 0.0111, 0.0112, 0.0113, 0.0114, 0.0115],
    [0.0111, 0, 0.0113, 0.0112, 0.0114, 0.0111, 0.0112, 0.0116],
    [0.0113, 0.0115, 0, 0.0114, 0.0111, 0.0112, 0.0113, 0.0112],
    [0.0112, 0.0113, 0.0112, 0, 0.0116, 0.0114, 0.0113, 0.0115],
    [0.0111, 0.0112, 0.0111, 0.0112, 0, 0.0113, 0.0114, 0.0115],
    [0.0113, 0.0114, 0.0115, 0.0112, 0.0113, 0, 0.0116, 0.0114],
    [0.0114, 0.0113, 0.0115, 0.0116, 0.0114, 0.0115, 0, 0.0113],
    [0.0115, 0.0112, 0.0113, 0.0114, 0.0115, 0.0114, 0.0116, 0]
])

# 设置功能区标签
labels = ['DMN', 'FPN', 'L', 'VAN', 'DAN', 'SMN', 'V', 'CS & SB']

# 准备连接数据
connections = [(i, j, matrix[i, j]) for i in range(len(labels)) for j in range(len(labels)) if i != j]
print(connections)

# 创建弦图
chord = hv.Chord(connections)

# 设置绘图选项
chord.opts(
    opts.Chord(
        cmap='Blues',  # 使用蓝色调的颜色映射
        edge_color='source',  # 直接指定边的颜色
        labels='index',  # 标签
        node_color='index',  # 节点颜色
        edge_cmap='Blues',  # 边的颜色映射
        title="Functional Connectivity"  # 图表标题
    )
)
# 保存图表为 HTML 文件
hv.save(chord, save_path)

# 输出保存路径
print(f"图表已保存为 {save_path}")
