import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
import pandas as pd
import scipy.io as sio

def visualize_fc_matrix(fc_matrix):

    """plt.figure(figsize=(8, 8))  # 设置图形大小
    cmap = LinearSegmentedColormap.from_list('blue_yellow_white', ['blue', 'red'])
    plt.imshow(fc_matrix, cmap='viridis',interpolation='nearest', vmin=0, vmax=1)  # 使用 'bwr' 颜色图，设置范围为 [-1, 1]
    plt.colorbar()  # 显示颜色条
    num_nodes = fc_matrix.shape[0]
    plt.plot(np.arange(num_nodes), np.arange(num_nodes), color='red', linewidth=1.5)
    plt.title("Functional Connectivity Matrix (Thresholded)")
    plt.show()"""

    plt.figure(figsize=(8, 8))
    plt.imshow(fc_matrix, cmap='viridis', interpolation='none')
    # plt.imshow(fc_matrix, cmap='viridis', interpolation='nearest')
    plt.colorbar()  # Adds a colorbar to the side to indicate the scale
    plt.title('200-Node Functional Connectivity Matrix')
    plt.xlabel('Nodes')
    plt.ylabel('Nodes')
    plt.show()

def calculate_average_fc_matrix(fc_matrices):
    avg_fc_matrix = np.mean(fc_matrices, axis=0)
    return avg_fc_matrix

def save_fc_matrix_to_edge(avg_fc_matrix, filename):
    with open(filename, 'w') as f:
        # 遍历矩阵的每一行
        for row in avg_fc_matrix:
            # 将每一行的元素转换为字符串，并以空格分隔
            #row_str = ' '.join(f'{val:.1f}' for val in row)
            row_str = ' '.join(str(val) for val in row)
            # 写入文件并换行
            f.write(row_str + '\n')

file_path = r'D:\PLSNet-main\util\abide\time-matrix2.npy'  # 替换为你的文件路径
data = np.load(file_path)
visualize_fc_matrix(data)

