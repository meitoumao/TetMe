import matplotlib.pyplot as plt
import numpy as np

# 创建一个简单的图形
def generate_cartoon_label_map(title):
    # 定义图的尺寸
    fig, ax = plt.subplots(figsize=(5, 5))

    # 创建一个简单的标签区域，使用不同的颜色表示不同的区域
    label_map = np.random.randint(1, 5, (10, 10))  # 生成一个10x10的标签区域，值从1到4不等

    # 使用imshow显示标签区域
    ax.imshow(label_map, cmap='tab10', interpolation='nearest')

    # 设置标题
    ax.set_title(title)

    # 关闭坐标轴
    ax.axis('off')

    # 显示图形
    plt.show()

# 生成ASD患者的标签图
generate_cartoon_label_map('ASD患者标签图')

# 生成正常人的标签图
generate_cartoon_label_map('正常人标签图')
