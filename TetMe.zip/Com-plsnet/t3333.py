import matplotlib.pyplot as plt
import numpy as np

# 定义节点标签
labels = ['A', 'B', 'C', 'D']
num_nodes = len(labels)

# 定义连接关系的邻接矩阵
matrix = np.array([
    [0, 5, 3, 2],
    [5, 0, 4, 3],
    [3, 4, 0, 7],
    [2, 3, 7, 0]
])

# 绘制节点
theta = np.linspace(0, 2*np.pi, num_nodes, endpoint=False).tolist()
fig, ax = plt.subplots(figsize=(8, 8))
ax.set_aspect('equal')
ax.set_axis_off()

# 绘制节点
for i, (label, angle) in enumerate(zip(labels, theta)):
    x = np.cos(angle)
    y = np.sin(angle)
    ax.plot(x, y, marker='o', markersize=20, label=label, linestyle='', color='C{}'.format(i))

# 绘制连线
for i in range(num_nodes):
    for j in range(i+1, num_nodes):
        if matrix[i, j] > 0:
            x1 = np.cos(theta[i])
            y1 = np.sin(theta[i])
            x2 = np.cos(theta[j])
            y2 = np.sin(theta[j])
            ax.plot([x1, x2], [y1, y2], color='grey')

# 添加标签
ax.legend(loc='upper right', fontsize=12)

plt.show()
