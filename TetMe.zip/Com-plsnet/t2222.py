import matplotlib.pyplot as plt
import numpy as np
import networkx as nx
from matplotlib.colors import ListedColormap
import matplotlib
from matplotlib.patches import Patch
import random
import math
# 计算每个节点在圆上的角度
def get_angle(pos):
    return math.atan2(pos[1], pos[0])

def get_distance(u, v, pos):
    # 计算节点 u 和 v 之间的欧几里得距离
    return np.linalg.norm(np.array(pos[u]) - np.array(pos[v]))


#datas=np.load(r"D:\Com-BrainTF-main\source\result\attnWeights_test.npy",allow_pickle=True)
datas=np.load(r"F:\Com-plsnet3\source\result\attnWeights_test.npy",allow_pickle=True)
concatenated_matrix = np.concatenate(datas, axis=0)
average_attention = np.mean(concatenated_matrix, axis=1)
average_matrix = np.mean(average_attention, axis=0)
data=average_matrix
data=data[1:,1:]


connection_strength=data
n_nodes = 116
"""
connection_strength = np.random.rand(n_nodes, n_nodes) * 0.1
connection_strength = (connection_strength + connection_strength.T) / 2  # 保证对称
print(connection_strength.shape)
"""

print(connection_strength)
# 创建网络图
G = nx.DiGraph()

# 添加节点
for i in range(n_nodes):
    G.add_node(i)

# 添加连接边
for i in range(n_nodes):
    for j in range(i+1, n_nodes):
        if connection_strength[i, j] > 0.011:  # 设置阈值，过滤弱连接
            G.add_edge(i, j, weight=connection_strength[i, j])
# 定义颜色映射表，代表不同的功能网络
color_map = ['#00FF00', '#FF00FF', '#808080', '#FF8000', '#FFFF00', '#8000FF','#FF0000']
categories = ["CB", "V", "DMN", "FPN", "SMN", "L","VAN"]
print(len(G.edges))

nodes_per_category = [26, 16, 24,10, 14, 20,6]  # 每个类别的节点数
node_color = []
node_labels = []
category_index = 0

for idx, num_nodes in enumerate(nodes_per_category):
    for i in range(num_nodes):
        node_color.append(color_map[idx])  # 为每个类别分配颜色
        node_labels.append(categories[idx])  # 为每个节点分配类别标签


# 生成圆形布局
pos = nx.circular_layout(G, scale=1)
weights = [d['weight'] for _, _, d in G.edges(data=True)]
norm = matplotlib.colors.Normalize(vmin=min(weights), vmax=max(weights))
# 绘制图像
plt.figure(figsize=(15,10))
#edges = nx.draw_networkx_edges(G, pos, edge_color=[d['weight'] for _, _, d in G.edges(data=True)],arrows=True,connectionstyle='arc3,rad=0.3', edge_cmap=plt.cm.Blues, width=7)

weights = [d['weight'] for _, _, d in G.edges(data=True)]
vmin, vmax = min(weights), max(weights)

# 生成颜色映射
norm = plt.Normalize(vmin=vmin, vmax=vmax)
cmap = plt.cm.GnBu

# 绘制节点
plt.figure(figsize=(10, 10))
nx.draw_networkx_nodes(G, pos, node_size=100, node_color='skyblue')
sorted_edges = sorted(G.edges(data=True), key=lambda x: x[2]['weight'])

# 绘制每条边，并为每条边设置颜色和随机弧度
for idx, (u, v, d) in enumerate(sorted_edges):
    # 随机生成弧度，范围可以根据需要调整
    angle_u = get_angle(pos[u])
    angle_v = get_angle(pos[v])
    x_u, y_u = pos[u]
    x_v, y_v = pos[v]
    distance = math.sqrt((x_v - x_u) ** 2 + (y_v - y_u) ** 2)
    if angle_u > angle_v:
        rad = 1 / distance
        if distance>1.5:
            rad=0.2
    else:
        rad = -(1 / distance)
        if distance>1.5:
            rad=-0.2

    """weight=d['weight']
    alpha = 1.0 - (weight - vmin) / (vmax - vmin)"""
    edge_color = cmap(norm(d['weight']))

    # 绘制边，带上随机弧度
    nx.draw_networkx_edges(
        G, pos,
        edgelist=[(u, v)],
        edge_color=[edge_color],  # 单独的边的颜色
        connectionstyle=f'arc3,rad={rad}',  # 设置随机弧度
        width=3
    )
nodes = nx.draw_networkx_nodes(G, pos, node_size=100, cmap=ListedColormap(color_map),node_color=node_color)

legend_elements = [Patch(facecolor=color_map[i], label=categories[i]) for i in range(len(categories))]
plt.legend(handles=legend_elements, loc='best', bbox_to_anchor=(1, 0.5), title="Categories")

# 创建颜色条
sm = plt.cm.ScalarMappable(cmap=plt.cm.Blues, norm=plt.Normalize(vmin=0.0112, vmax=0.0116))
plt.colorbar(sm,orientation='horizontal')

# 显示
plt.gca().set_aspect('equal')  # 设置图形比例为1:1，确保为正圆
plt.axis('off')
plt.show()

