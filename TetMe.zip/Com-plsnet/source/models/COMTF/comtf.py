import torch
import torch.nn as nn
from torch.nn import TransformerEncoderLayer
from .ptdec import DEC
from typing import List
from .components import InterpretableTransformerEncoder
from source.models.COMTF.components.transformer_2 import InterpretableTransformerEncoder2
from source.models.COMTF.components.encoder import Encoder
from omegaconf import DictConfig
from ..base import BaseModel
import pickle
from torch.nn import Conv1d, MaxPool1d, Linear, GRU
import torch.nn.functional as F
import numpy as np

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
class TransPoolingEncoder(nn.Module):
    """
    Transformer encoder with Pooling mechanism.
    Input size: (batch_size, input_node_num, input_feature_size)
    Output size: (batch_size, output_node_num, input_feature_size)
    """
    #local:200 200 1024 8 false T T T 8 T
    def __init__(self, input_feature_size, input_node_num, hidden_size, output_node_num, pooling=True, orthogonal=True, freeze_center=False, project_assignment=True, nHead=4, local_transformer=False):
        super().__init__()
        self.transformer = InterpretableTransformerEncoder(d_model=input_feature_size, nhead=nHead,
                                                           dim_feedforward=hidden_size,
                                                           batch_first=True)
        self.local_transformer = local_transformer
        if local_transformer:
            self.pooling = False
        else:
            self.pooling = pooling
        if self.pooling:
            encoder_hidden_size = 32
            self.encoder = nn.Sequential(
                nn.Linear(input_feature_size *
                          input_node_num, encoder_hidden_size),
                nn.LeakyReLU(),
                nn.Linear(encoder_hidden_size, encoder_hidden_size),
                nn.LeakyReLU(),
                nn.Linear(encoder_hidden_size,
                          input_feature_size * input_node_num),
            )
            # 每个聚类中心的节点表示”是指在聚类分析或图神经网络中，对属于同一个聚类中心的节点的特征进行加权求和，从而得到该聚类中心的一个代表性向量。
            # 这个向量综合了所有分配给该聚类中心的节点的特征信息，起到了“代表”这个聚类中心的作用。
            self.dec = DEC(cluster_number=output_node_num, hidden_dimension=input_feature_size, encoder=self.encoder,#8 200
                           orthogonal=orthogonal, freeze_center=freeze_center, project_assignment=project_assignment)

        if local_transformer:#8个可训练张量 8个分组令牌 也就是论文中的p
            self.class_token = nn.ParameterList()
            self.class_token.append(nn.Parameter(torch.Tensor(1,input_feature_size), requires_grad = True).cuda())
            self.class_token.append(nn.Parameter(torch.Tensor(1,input_feature_size), requires_grad = True).cuda())
            self.class_token.append(nn.Parameter(torch.Tensor(1,input_feature_size), requires_grad = True).cuda())
            self.class_token.append(nn.Parameter(torch.Tensor(1,input_feature_size), requires_grad = True).cuda())
            self.class_token.append(nn.Parameter(torch.Tensor(1,input_feature_size), requires_grad = True).cuda())
            self.class_token.append(nn.Parameter(torch.Tensor(1,input_feature_size), requires_grad = True).cuda())
            self.class_token.append(nn.Parameter(torch.Tensor(1,input_feature_size), requires_grad = True).cuda())
            self.class_token.append(nn.Parameter(torch.Tensor(1,input_feature_size), requires_grad = True).cuda())
        self.reset_parameters(local_transformer)

        self.mlp = nn.Sequential(
            nn.Linear(8*input_feature_size, 1024),
            nn.Linear(1024, input_feature_size),
            nn.ReLU()
        )

    def reset_parameters(self, local_transformer=False):
        if local_transformer:
            for i in range(len(self.class_token)):
                self.class_token[i] = nn.init.xavier_normal_(self.class_token[i])


    def is_pooling_enabled(self):
        return self.pooling

    def forward(self,
            x: torch.tensor, cluster_num=-1):
        bz, node_num, dim = x.shape
        if self.local_transformer:
            class_token = self.class_token[cluster_num]
            class_token = class_token.repeat(bz,1,1)
            x = torch.cat((class_token, x), dim=1)

        x = self.transformer(x)

        if self.local_transformer:
            cls_token = x[:, 0, :]#令牌
            x = x[:, 1:, :]
            return x, None, cls_token.reshape(x.shape[0], 1, -1)
        else:
            cls_token = x[:, 0, :]
            x = x[:, 1:, :]
            if self.pooling:
                x, assignment = self.dec(x)#(64 8 200) (64,200,8)
                return x, assignment, cls_token.reshape(x.shape[0], 1, -1)
            else:
                return x, None, cls_token.reshape(x.shape[0], 1, -1)

    def get_attention_weights(self):
        return self.transformer.get_attention_weights()

    def loss(self, assignment):
        return self.dec.loss(assignment)


class TransPoolingEncoder2(nn.Module):
    """
    Transformer encoder with Pooling mechanism.
    Input size: (batch_size, input_node_num, input_feature_size)
    Output size: (batch_size, output_node_num, input_feature_size)
    """

    def __init__(self, input_feature_size, input_node_num, hidden_size, output_node_num, pooling=True, orthogonal=True,
                 freeze_center=False, project_assignment=True, nHead=4):
        super().__init__()
        self.transformer = InterpretableTransformerEncoder2(d_model=input_feature_size, nhead=nHead,input_node_num=input_node_num,
                                                           dim_feedforward=hidden_size,
                                                           batch_first=True)
        self.pooling = pooling
        if self.pooling:
            encoder_hidden_size = 32
            self.encoder = nn.Sequential(
                nn.Linear(input_feature_size *
                          input_node_num, encoder_hidden_size),
                nn.LeakyReLU(),
                nn.Linear(encoder_hidden_size, encoder_hidden_size),
                nn.LeakyReLU(),
                nn.Linear(encoder_hidden_size,
                          input_feature_size * input_node_num),
            )
            # 每个聚类中心的节点表示”是指在聚类分析或图神经网络中，对属于同一个聚类中心的节点的特征进行加权求和，从而得到该聚类中心的一个代表性向量。
            # 这个向量综合了所有分配给该聚类中心的节点的特征信息，起到了“代表”这个聚类中心的作用。
            self.dec = DEC(cluster_number=output_node_num, hidden_dimension=input_feature_size, encoder=self.encoder,
                           # 8 200
                           orthogonal=orthogonal, freeze_center=freeze_center, project_assignment=project_assignment)

        self.mlp = nn.Sequential(
            nn.Linear(8 * input_feature_size, 1024),
            nn.Linear(1024, input_feature_size),
            nn.ReLU()
        )

    def reset_parameters(self, local_transformer=False):
        if local_transformer:
            for i in range(len(self.class_token)):
                self.class_token[i] = nn.init.xavier_normal_(self.class_token[i])

    def is_pooling_enabled(self):
        return self.pooling

    def forward(self,
                x: torch.tensor):
        bz, node_num, dim = x.shape
        cls_token = x[:, 0, :]
        x = x[:, 1:, :]
        x = self.transformer(x)
        x1=x
        x, assignment = self.dec(x)  # (64 8 200) (64,200,8)
        return x1, assignment, cls_token.reshape(x.shape[0], 1, -1)


    def get_attention_weights(self):
        return self.transformer.get_attention_weights()

    def loss(self, assignment):
        return self.dec.loss(assignment)

"""class GCNPredictor(nn.Module):

    def __init__(self, node_input_dim, roi_num=360):#111 111
        super().__init__()
        inner_dim = roi_num#200
        self.roi_num = roi_num
        self.gcn = nn.Sequential(
            nn.Linear(node_input_dim, inner_dim),
            nn.LeakyReLU(negative_slope=0.2),
            Linear(inner_dim, inner_dim)
        )
        self.bn1 = torch.nn.BatchNorm1d(inner_dim)

        self.gcn1 = nn.Sequential(
            nn.Linear(inner_dim, inner_dim),
            nn.LeakyReLU(negative_slope=0.2),
        )
        self.bn2 = torch.nn.BatchNorm1d(inner_dim)
        self.gcn2 = nn.Sequential(
            nn.Linear(inner_dim, 64),
            nn.LeakyReLU(negative_slope=0.2),
            nn.Linear(64, 8),
            nn.LeakyReLU(negative_slope=0.2),
        )
        self.bn3 = torch.nn.BatchNorm1d(inner_dim)


        self.fcn = nn.Sequential(
            nn.Linear(int(8 * int(roi_num * 0.7)), 256),
            # nn.Linear(8 * roi_num, 256),
            nn.LeakyReLU(negative_slope=0.2),
            nn.Linear(256, 32),
            nn.LeakyReLU(negative_slope=0.2),
            nn.Linear(32, 2)
        )
        self.norm = torch.nn.LayerNorm(normalized_shape=roi_num, elementwise_affine=True)
        self.weight = torch.nn.Parameter(torch.Tensor(1, 8))

        self.softmax = nn.Sigmoid()


    def forward(self, m):
        bz = m.shape[0]#16
        x = torch.einsum('ijk,ijp->ijp', m, m)

        x = self.gcn(x)


        x = x.reshape((bz*self.roi_num, -1))
        x = self.bn1(x)
        x = x.reshape((bz, self.roi_num, -1))

        ""x = torch.einsum('ijk,ijp->ijp', m, x)

        x = self.gcn1(x)

        x = x.reshape((bz*self.roi_num, -1))
        x = self.bn2(x)
        x = x.reshape((bz, self.roi_num, -1))""
        
        x = torch.einsum('ijk,ijp->ijp', m, x)
        x = self.gcn2(x)
        x = self.bn3(x)# 16 200 8

        score = (x * self.weight).sum(dim=-1)
        kscore = score  # [16 200]
        score = self.softmax(score)
        sc = score#[16 200]

        _, idx = score.sort(dim=-1)  #idx为排序前位置索引


        _, rank = idx.sort(dim=-1) # 根据排序后的索引计算排名 索引的索引

        l = int(m.shape[1] * 0.7)#200*0.7

        x_p = torch.empty(bz, l, 8) #16,140 8

        for i in range(x.shape[0]):
            x_p[i] = x[i, idx[i, :l], :]

        x = x_p.view(bz,-1).to(device)


        # x = x.view(bz,-1).to(device)
        # return self.fcn(x), x
        return self.fcn(x),sc """

class GCNPredictor(nn.Module):

    def __init__(self, node_input_dim, roi_num=360):#111 111
        super().__init__()
        inner_dim = roi_num#200
        self.roi_num = roi_num
        self.gcn = nn.Sequential(
            nn.Linear(node_input_dim, inner_dim),
            nn.LeakyReLU(negative_slope=0.2),
            Linear(inner_dim, inner_dim)
        )
        self.bn1 = torch.nn.BatchNorm1d(inner_dim)

        self.gcn1 = nn.Sequential(
            nn.Linear(inner_dim, inner_dim),
            nn.LeakyReLU(negative_slope=0.2),
        )
        self.bn2 = torch.nn.BatchNorm1d(inner_dim)
        self.gcn2 = nn.Sequential(
            nn.Linear(inner_dim, 64),
            nn.LeakyReLU(negative_slope=0.2),
            nn.Linear(64, 8),
            nn.LeakyReLU(negative_slope=0.2),
        )
        self.bn3 = torch.nn.BatchNorm1d(inner_dim)


        self.fcn = nn.Sequential(
            nn.Linear(int(8 * int(roi_num )), 256),
            # nn.Linear(8 * roi_num, 256),
            nn.LeakyReLU(negative_slope=0.2),
            nn.Linear(256, 32),
            nn.LeakyReLU(negative_slope=0.2),
            nn.Linear(32, 2)
        )
        self.norm = torch.nn.LayerNorm(normalized_shape=roi_num, elementwise_affine=True)
        self.weight = torch.nn.Parameter(torch.Tensor(1, 8))

        self.softmax = nn.Sigmoid()


    def forward(self, m,node_feature):
        bz = m.shape[0]#16
        x = torch.einsum('ijk,ijp->ijp', m, node_feature)
        x = self.gcn(x)


        x = x.reshape((bz*self.roi_num, -1))
        x = self.bn1(x)
        x = x.reshape((bz, self.roi_num, -1))

        x = torch.einsum('ijk,ijp->ijp', m, x)

        x = self.gcn1(x)

        """x = x.reshape((bz*self.roi_num, -1))
        x = self.bn2(x)
        x=x.reshape((bz,self.roi_num,-1))

        x = torch.einsum('ijk,ijp->ijp', m, x)"""
        x = self.gcn2(x)
        x = self.bn3(x)# 16 200 8

        score = (x * self.weight).sum(dim=-1)
        score = self.softmax(score)
        sc = score  # [16 200]
        x = x.view(bz, -1).to(device)
        # x = x_p.view(bz,-1).to(device)
        # return self.fcn(x), x
        return self.fcn(x),sc


def pearson_corrcoef(data):
    # 数据的均值和标准差
    mean = torch.mean(data, dim=2, keepdim=True)
    std = torch.std(data, dim=2, unbiased=False, keepdim=True)

    # 标准化数据
    data_centered = data - mean
    data_standardized = data_centered / std

    # 计算相关系数矩阵
    correlation_matrix = torch.matmul(data_standardized, data_standardized.transpose(1, 2)) / (data.size(2) - 1)

    return correlation_matrix

class Embed2GraphByProduct(nn.Module):#8 111

    def __init__(self):
        super().__init__()

    def forward(self, x):


        m = torch.einsum('ijk,ipk->ijp', x, x)
        #m 16,111,111

        m = torch.unsqueeze(m, -1)

        return m




class DeepTimeEmbedding(nn.Module):
    def __init__(self):
        super(DeepTimeEmbedding, self).__init__()

        # 第一层卷积，将时间维度从 100 映射到 128
        self.conv1 = nn.Conv1d(in_channels=100, out_channels=128, kernel_size=3, padding=1)
        self.relu1 = nn.ReLU()

        # 第二层卷积，将时间维度从 128 映射到 256
        self.conv2 = nn.Conv1d(in_channels=128, out_channels=256, kernel_size=3, padding=1)
        self.relu2 = nn.ReLU()

        # 第三层卷积，将时间维度从 256 映射到 200
        self.conv3 = nn.Conv1d(in_channels=256, out_channels=200, kernel_size=3, padding=1)
        self.relu3 = nn.ReLU()

    def forward(self, x):
        x = x.permute(0, 2, 1)  # 将时间维度移到中间，变为 [batch_size, 100, 200]

        x = self.conv1(x)  # 卷积层1 [batch_size, 128, 200]
        x = self.relu1(x)  # 激活函数1

        x = self.conv2(x)  # 卷积层2 [batch_size, 256, 200]
        x = self.relu2(x)  # 激活函数2

        x = self.conv3(x)  # 卷积层3 [batch_size, 200, 200]
        x = self.relu3(x)  # 激活函数3

        x = x.permute(0, 2, 1)  # 调整回原来的维度顺序，变为 [batch_size, 200, 200]
        return x

class TimeEmbedding(nn.Module):
    def __init__(self):
        super(TimeEmbedding, self).__init__()
        self.conv = nn.Conv1d(in_channels=100, out_channels=200, kernel_size=1)

    def forward(self, x):
        x = x.permute(0, 2, 1)  # 将时间维度移到中间，变为 [64, 100, 200]
        x = self.conv(x)  # 使用1D卷积，将时间维度从100映射到200
        x = x.permute(0, 2, 1)  # 调整回原来的维度顺序，变为 [64, 200, 200]
        return x


class ComBrainTF(BaseModel):

    def __init__(self, config: DictConfig,roi_num=360, node_feature_dim=360):
        super().__init__()
        self.attention_list = nn.ModuleList()
        self.attention_list2=nn.ModuleList()
        forward_dim = config.dataset.node_sz
        timeseries_sz=config.dataset.timeseries_sz

        self.pos_encoding = config.model.pos_encoding
        if self.pos_encoding == 'identity':
            self.node_identity = nn.Parameter(torch.zeros(
                config.dataset.node_sz, config.model.pos_embed_dim), requires_grad=True)
            forward_dim = config.dataset.node_sz + config.model.pos_embed_dim
            nn.init.kaiming_normal_(self.node_identity)

        self.num_MHSA = config.model.num_MHSA
        sizes = config.model.sizes
        sizes[0] = config.dataset.node_sz
        in_sizes = [config.dataset.node_sz] + sizes[:-1]
        do_pooling = config.model.pooling
        self.do_pooling = do_pooling

        self.local_transformer = TransPoolingEncoder(input_feature_size=forward_dim,
                                                     input_node_num=in_sizes[1],
                                                     hidden_size=1024,
                                                     output_node_num=sizes[1],
                                                     pooling=False,
                                                     orthogonal=config.model.orthogonal,
                                                     freeze_center=config.model.freeze_center,
                                                     project_assignment=config.model.project_assignment,
                                                     nHead=config.model.nhead,
                                                     local_transformer=True)

        self.global_transformer = TransPoolingEncoder2(input_feature_size=forward_dim,
                                                     input_node_num=in_sizes[1],
                                                     hidden_size=1024,
                                                     output_node_num=sizes[1],
                                                     pooling=False,
                                                     orthogonal=config.model.orthogonal,
                                                     freeze_center=config.model.freeze_center,
                                                     project_assignment=config.model.project_assignment,
                                                     nHead=config.model.nhead)

        self.time_transformer = Encoder(input_dim=timeseries_sz,input_dim2=forward_dim,num_head=4,embed_dim=4)
        self.emb2graph = Embed2GraphByProduct()
        self.cnn = TimeEmbedding()

        if config.model.num_MHSA == 1:
                self.attention_list.append(
                    TransPoolingEncoder(input_feature_size=forward_dim,
                                        input_node_num=in_sizes[1],
                                        hidden_size=1024,
                                        output_node_num=sizes[1],
                                        pooling=do_pooling[1],
                                        orthogonal=config.model.orthogonal,
                                        freeze_center=config.model.freeze_center,
                                        project_assignment=config.model.project_assignment,
                                        nHead=config.model.nhead,
                                        local_transformer=False))

                self.attention_list.append(TransPoolingEncoder2(input_feature_size=forward_dim,
                                                                input_node_num=in_sizes[1],
                                                                hidden_size=1024,
                                                                output_node_num=sizes[1],
                                                                pooling=True,
                                                                orthogonal=config.model.orthogonal,
                                                                freeze_center=config.model.freeze_center,
                                                                project_assignment=config.model.project_assignment,
                                                                nHead=config.model.nhead))
        else:
            for index, size in enumerate(sizes):
                self.attention_list.append(
                    TransPoolingEncoder(input_feature_size=forward_dim,
                                        input_node_num=in_sizes[index],
                                        hidden_size=1024,
                                        output_node_num=size,
                                        pooling=do_pooling[index],
                                        orthogonal=config.model.orthogonal,
                                        freeze_center=config.model.freeze_center,
                                        project_assignment=config.model.project_assignment,
                                        nHead=config.model.nhead,
                                        local_transformer=False))

        self.dim_reduction = nn.Sequential(
            nn.Linear(forward_dim, 8),
            nn.LeakyReLU()
        )

        self.fc = nn.Sequential(
            nn.Linear(8 * sizes[-1], 256),
            nn.LeakyReLU(),
            nn.Linear(256, 32),
            nn.LeakyReLU(),
            nn.Linear(32, 2)
        )

        self.assignMat = None
        self.mlp = nn.Sequential(
            nn.Linear(8 * forward_dim, 512),
            nn.LeakyReLU(),
            nn.Linear(512, forward_dim),
            nn.LeakyReLU()
        )
        self.predictor = GCNPredictor(forward_dim, roi_num=sizes[0])

        with open(r"D:\Com-plsnet\node_clus_map.pickle", 'rb') as handle:
            self.node_clus_map = pickle.load(handle)

        self.node_rearranged_len = [41, 70, 91, 110, 130, 137, 158, 200]
        #self.node_rearranged_len = [26, 42, 66, 76, 90, 110,116]
    def rearrange_node_feature(self, node_feature_rearranged, node_feature, rearranged_indices):
        # Rearrange according to node_clus_map which is a dictionary {0:1, 1:3, .... 199:7}
        node_feature_rearranged = node_feature[:, rearranged_indices, :]
        node_feature_rearranged = node_feature_rearranged[:, :, rearranged_indices]
        return node_feature_rearranged

    def forward(self,
                time_seires: torch.tensor,
                node_feature: torch.tensor):
        bz, _, _, = node_feature.shape
        if self.pos_encoding == 'identity':
            pos_emb = self.node_identity.expand(bz, *self.node_identity.shape)
            node_feature = torch.cat([node_feature, pos_emb], dim=-1)
        assignments = []
        attn_weights = []
        node_feature_rearranged = torch.tensor(node_feature.shape).cuda()
        node_feature_rearranged = self.rearrange_node_feature(node_feature_rearranged, node_feature, list(self.node_clus_map.keys()))
        node_feature_rearranged[:,:self.node_rearranged_len[0], :], _, local_class_tokens0  = self.local_transformer(node_feature_rearranged[:, :self.node_rearranged_len[0], :], cluster_num = 0)
        node_feature_rearranged[:,self.node_rearranged_len[0]:self. node_rearranged_len[1], :], _, local_class_tokens1 = self.local_transformer(node_feature_rearranged[:, self.node_rearranged_len[0]:self.node_rearranged_len[1], :], cluster_num = 1)
        node_feature_rearranged[:,self.node_rearranged_len[1]:self.node_rearranged_len[2], :], _, local_class_tokens2 = self.local_transformer(node_feature_rearranged[:, self.node_rearranged_len[1]:self.node_rearranged_len[2], :], cluster_num = 2)
        node_feature_rearranged[:,self.node_rearranged_len[2]:self.node_rearranged_len[3], :], _, local_class_tokens3 = self.local_transformer(node_feature_rearranged[:, self.node_rearranged_len[2]:self.node_rearranged_len[3], :], cluster_num = 3)
        node_feature_rearranged[:,self.node_rearranged_len[3]:self.node_rearranged_len[4], :], _, local_class_tokens4 = self.local_transformer(node_feature_rearranged[:, self.node_rearranged_len[3]:self.node_rearranged_len[4], :], cluster_num = 4)
        node_feature_rearranged[:,self.node_rearranged_len[4]:self.node_rearranged_len[5], :], _, local_class_tokens5 = self.local_transformer(node_feature_rearranged[:, self.node_rearranged_len[4]:self.node_rearranged_len[5], :], cluster_num = 5)
        node_feature_rearranged[:,self.node_rearranged_len[5]:self.node_rearranged_len[6], :], _, local_class_tokens6 = self.local_transformer(node_feature_rearranged[:, self.node_rearranged_len[5]:self.node_rearranged_len[6], :], cluster_num = 6)
        node_feature_rearranged[:,self.node_rearranged_len[6]:self.node_rearranged_len[7], :], _, local_class_tokens7 = self.local_transformer(node_feature_rearranged[:, self.node_rearranged_len[6]:self.node_rearranged_len[7], :], cluster_num = 7)

        node_feature = node_feature_rearranged
        #node_feature=self.global_transformer(node_feature)
        self.local_transformer(node_feature_rearranged[:, :self.node_rearranged_len[0], :], cluster_num=0)
        class_token = torch.cat(
            (local_class_tokens0, local_class_tokens1, local_class_tokens2, local_class_tokens3, local_class_tokens4,
             local_class_tokens5, local_class_tokens6, local_class_tokens7), dim=1)  # torch.Size([64, 8, 200])
        class_token = class_token.reshape((bz, -1))  # torch.Size([64, 1600]
        class_token = self.mlp(class_token)  # torch.Size([64, 200])
        class_token = class_token.reshape((bz, 1, -1))  # torch.Size([64,1, 200])
        node_feature = torch.cat((class_token, node_feature), dim=1)  # torch.Size([64,201, 200])
        if self.num_MHSA == 1:
            node_feature, assign_mat, cls_token = self.attention_list[1](node_feature)
            assignments.append(assign_mat)
            attn_weights.append(self.attention_list[1].get_attention_weights())
        else:
            for atten in self.attention_list:
                node_feature, _, cls_token = atten(node_feature)
                attn_weights.append(atten.get_attention_weights())
        self.assignMat = assignments[0]
        timeseires_tran=self.time_transformer(time_seires)
        timeseires_tran = F.softmax(timeseires_tran, dim=-1)
        timeseires_tran = torch.bmm(timeseires_tran, torch.transpose(timeseires_tran, 1, 2))
        """timeseires_tran = self.emb2graph(timeseires_tran)  # m=16,200,200,1
        timeseires_tran = timeseires_tran[:, :, :, 0]"""
        time_seires_rearranged = torch.tensor(node_feature.shape).cuda()
        timeseires_tran = self.rearrange_node_feature(time_seires_rearranged, timeseires_tran,
                                                              list(self.node_clus_map.keys()))

        #timeseires_tran = self.cnn(timeseires_tran) # 输出形状为 [64, 200, 200
        """timeseires_tran = F.softmax(timeseires_tran, dim=-1)
        timeseires_tran  = self.emb2graph(timeseires_tran)  # m=16,200,200,1
        timeseires_tran  = timeseires_tran [:, :, :, 0]  # m=16,200,200"""

        """node_feature = self.dim_reduction(node_feature)  # node_feature:64 8 200->64 8 8

        node_feature = node_feature.reshape((bz, -1))  # 64 64"""

        #return self.fc(node_feature), None  # 64 2
        node_feature=torch.transpose(node_feature,1,2)
        return self.predictor(timeseires_tran,node_feature), None


    def get_assign_mat(self):
        return self.assignMat

    def get_attention_weights(self):
        attention_list2 = self.attention_list[1]
        self.attention_list2.append(attention_list2)
        return [atten.get_attention_weights() for atten in self.attention_list2]

    def get_local_attention_weights(self):
        print("999")
        return self.local_transformer.get_attention_weights()

    def get_cluster_centers(self) -> torch.Tensor:
        """
        Get the cluster centers, as computed by the encoder.

        :return: [number of clusters, hidden dimension] Tensor of dtype float
        """
        return self.dec.get_cluster_centers()

    def loss(self, assignments):
        """
        Compute KL loss for the given assignments. Note that not all encoders contain a pooling layer.
        Inputs: assignments: [batch size, number of clusters]
        Output: KL loss
        """
        print("11 11")
        decs = list(
            filter(lambda x: x.is_pooling_enabled(), self.attention_list))
        assignments = list(filter(lambda x: x is not None, assignments))
        loss_all = None

        for index, assignment in enumerate(assignments):
            if loss_all is None:
                loss_all = decs[index].loss(assignment)
            else:
                loss_all += decs[index].loss(assignment)
        return loss_all
