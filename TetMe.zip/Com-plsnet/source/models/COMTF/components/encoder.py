import torch.nn
import torch
import torch.nn.functional as F

class FullyConnectedOutput(torch.nn.Module):
    def __init__(self, embed_dim, input_dim):# 8 100
        super().__init__()
        self.fc = torch.nn.Sequential(
            torch.nn.Linear(embed_dim, 32),
            torch.nn.LeakyReLU(negative_slope=0.2),
            torch.nn.Dropout(p=0.1),
            torch.nn.Linear(32, embed_dim),
            torch.nn.LeakyReLU(negative_slope=0.2),
            torch.nn.Dropout(p=0.1)
        )

        self.norm = torch.nn.LayerNorm(normalized_shape=embed_dim, elementwise_affine=True)

    def forward(self, x):

        x = self.norm(x)


        # [b, 50, 32] -> [b, 50, 32]
        out = self.fc(x)

        return out



def attention(Q, K, V):
    dropout_p = 0.3
    l = Q.shape[3]  #
    num_head = Q.shape[1]  # 4
    Q = torch.nn.functional.elu(Q) + 1
    K = torch.nn.functional.elu(K) + 1
    attn = torch.matmul(K.transpose(-2, -1), V)

    attn = torch.softmax(attn, dim=-1)  # 暂时这样
    if dropout_p > 0.0:
        attn = torch.dropout(attn, p=dropout_p, train=True)
    # (B, Nt, Ns) x (B, Ns, E) -> (B, Nt, E)
    score = torch.matmul(Q, attn)
    score = score.permute(0, 3, 1, 2).reshape(-1, l, num_head * Q.shape[2])  # 16,111,32
    return score



class MultiHead(torch.nn.Module):
    def __init__(self, input_dim, num_head, embed_dim):
        super().__init__()

        self.num_head = num_head


        self.norm = torch.nn.LayerNorm(normalized_shape=input_dim, elementwise_affine=True)
        self.dropout = torch.nn.Dropout(p=0.1)

    def forward(self, Q, K, V):

        # Q, K, V = [b, 50, 32]
        b = Q.shape[0]#64
        len = Q.shape[1]#

        """Q = self.norm(Q)
        K = self.norm(K)
        V = self.norm(V)"""
        Q = Q.reshape(b, len, self.num_head, -1).permute(0, 2, 3, 1)
        K = K.reshape(b, len, self.num_head, -1).permute(0, 2, 3, 1)
        V = V.reshape(b, len, self.num_head, -1).permute(0, 2, 3, 1)

        score= attention(Q, K, V)
        return score


class EncoderLayer(torch.nn.Module):#Encoder(input_dim=time_series 100 , num_head=4, embed_dim=model_config['embedding_size'] 8)
    def __init__(self, input_dim,input_dim2, num_head, embed_dim):
        super(EncoderLayer, self).__init__()
        self.mh = MultiHead(input_dim, num_head, embed_dim)
        self.mh2 = MultiHead(input_dim2, num_head, embed_dim)

    def forward(self, x):
        x= self.mh(x, x, x)
        x=x.transpose(2, 1)
        x = self.mh2(x, x, x)
        x = x.transpose(2, 1)

        return x



class Encoder(torch.nn.Module):#Encoder(input_dim=time_series 100 , num_head=4, embed_dim=model_config['embedding_size'] 8)
    def __init__(self, input_dim,input_dim2,num_head, embed_dim):
        super(Encoder, self).__init__()
        self.layer = EncoderLayer(input_dim,input_dim2, num_head, embed_dim)
        self.norm1 = torch.nn.LayerNorm(input_dim, eps=1e-5)
        self.norm2 = torch.nn.LayerNorm(input_dim, eps=1e-5)

        self.linear1 = torch.nn.Linear(input_dim, 1024)
        self.activation = F.relu
        self.dropout = torch.nn.Dropout(0.3)
        self.linear2 = torch.nn.Linear(1024, input_dim)
        self.dropout2 = torch.nn.Dropout(0.3)
    def forward(self, x):
        x = self.norm1(x + self.layer(x))  # 残差连接
        x = self.norm2(x + self._ff_block(x))

        return x

    def _ff_block(self, x):
        x = self.linear2(self.dropout(self.activation(self.linear1(x))))
        return self.dropout2(x)
