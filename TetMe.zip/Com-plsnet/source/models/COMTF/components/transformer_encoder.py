from torch.nn import TransformerEncoderLayer
from torch import Tensor
from typing import Optional
import torch.nn.functional as F


class InterpretableTransformerEncoder(TransformerEncoderLayer):
    #local:200 4 1024  batch_first=T
    def __init__(self, d_model, nhead, dim_feedforward=2048, dropout=0.3, activation=F.relu,
                 layer_norm_eps=1e-5, batch_first=False, norm_first=False,
                 device=None, dtype=None) -> None:
        #super().__init__(d_model, nhead, dim_feedforward, dropout, activation)
        super().__init__(d_model, nhead, dim_feedforward, dropout, activation,
                         layer_norm_eps, batch_first, norm_first, device, dtype)
        self.attention_weights: Optional[Tensor] = None
        print(f"nhead = {nhead}")

    def _sa_block(self, x: Tensor,
                  attn_mask: Optional[Tensor], key_padding_mask: Optional[Tensor]) -> Tensor:
        x, weights = self.self_attn(x, x, x,  #自注意力  multiheadattention
                                    attn_mask=attn_mask,
                                    key_padding_mask=key_padding_mask,
                                    need_weights=True,
                                    average_attn_weights=False)
        """x=x.transpose(2, 1)
        x, weights = self.self_attn(x, x, x,  # 自注意力  multiheadattention
                                    attn_mask=attn_mask,
                                    key_padding_mask=key_padding_mask,
                                    need_weights=True,
                                    average_attn_weights=False)
        x=x.transpose(2, 1)"""
        self.attention_weights = weights
        return self.dropout1(x)

    def get_attention_weights(self) -> Optional[Tensor]:
        return self.attention_weights
