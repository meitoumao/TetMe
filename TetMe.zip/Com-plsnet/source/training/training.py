from source.utils import accuracy, TotalMeter, count_params, isfloat
import torch
import numpy as np
from pathlib import Path
import torch.nn.functional as F
from sklearn.metrics import roc_auc_score
from sklearn.metrics import precision_recall_fscore_support, classification_report
from source.utils import continus_mixup_data
import wandb
from typing import List
import torch.utils.data as utils
from source.components import LRScheduler
import logging
import argparse
from source.utils.loss import mixup_cluster_loss, topk_loss
import os
import torch.backends.cudnn as cudnn
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
import hydra
from omegaconf import DictConfig, open_dict
from source.dataset.dataset_fa import dataset_factory
from source.models.model_fa import model_factory
from source.components.fa import lr_scheduler_factory, optimizers_factory, logger_factory
from datetime import datetime
import time
import random

#time_matrix = []


class Train:
    """    return eval(train)(cfg=config,
                       model=model,
                       optimizers=optimizers,
                       lr_schedulers=lr_schedulers,
                       dataloaders=dataloaders,
                       logger=logger)"""

    def __init__(self, cfg: DictConfig,
                 model: torch.nn.Module,
                 optimizers: List[torch.optim.Optimizer],
                 lr_schedulers: List[LRScheduler],
                 dataloaders: List[utils.DataLoader],
                 logger: logging.Logger) -> None:

        self.config = cfg
        self.logger = logger
        self.model = model
        self.best_model=None
        self.best_acc=0
        self.logger.info(f'#model params: {count_params(self.model)}')
        self.train_dataloader, self.val_dataloader, self.test_dataloader = dataloaders
        self.epochs = cfg.training.epochs
        self.total_steps = cfg.total_steps
        self.optimizers = optimizers
        self.lr_schedulers = lr_schedulers
        self.loss_fn = torch.nn.CrossEntropyLoss(reduction='sum')
        self.save_path = Path(cfg.log_path) / cfg.unique_id
        self.save_learnable_graph = cfg.save_learnable_graph
        self.save_attn_weights = cfg.save_attn_weights
        self.save_test_attn_weights = cfg.save_test_attn_weights

        self.init_meters()
        self.mseLoss = torch.nn.MSELoss()
        self.l1Loss = torch.nn.L1Loss()
        self.pool_ratio=0.7

    def init_meters(self):
        self.train_loss, self.val_loss,\
            self.test_loss, self.train_accuracy,\
            self.val_accuracy, self.test_accuracy = [
                TotalMeter() for _ in range(6)]

    def reset_meters(self):
        for meter in [self.train_accuracy, self.val_accuracy,
                      self.test_accuracy, self.train_loss,
                      self.val_loss, self.test_loss]:
            meter.reset()

    def train_per_epoch(self, optimizer, lr_scheduler):
        self.model.train()
        for time_series, node_feature, label in self.train_dataloader:#torch.Size([64, 200, 100]) torch.Size([64, 200, 200]) torch.Size([64, 2])
            label = label.float()
            self.current_step += 1

            lr_scheduler.update(optimizer=optimizer, step=self.current_step)

            time_series, node_feature, label = time_series.cuda(), node_feature.cuda(), label.cuda()
            if self.config.preprocess.continus:
                time_series, node_feature, label = continus_mixup_data(
                    time_series, node_feature, y=label)
            # torch.Size([64, 200, 100]) torch.Size([64, 200, 200])
            label_fin=label[:,1]
            time_series, node_feature, targets_a, targets_b, lam = mixup_data(
                time_series, node_feature,  label_fin, 1, device)

            [predict,score], loss_pool = self.model(time_series, node_feature)
            #predict, loss_pool = self.model(time_series, node_feature)
            loss = self.loss_fn(predict, label)
            #loss += 0.001 * topk_loss(score, self.pool_ratio)
            #loss += mixup_cluster_loss(loss_pool,targets_a, targets_b, lam)
            self.train_loss.update_with_weight(loss.item(), label.shape[0])
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            top1 = accuracy(predict, label[:, 1])[0]
            self.train_accuracy.update_with_weight(top1, label.shape[0])

    def test_per_epoch(self, dataloader, loss_meter, acc_meter):
        labels = []
        result = []

        self.model.eval()

        for time_series, node_feature, label in dataloader:
            time_series, node_feature, label = time_series.cuda(), node_feature.cuda(), label.cuda()
            [output,score], loss_pool = self.model(time_series, node_feature)
            #output, loss_pool = self.model(time_series, node_feature)
            label = label.float()

            loss = self.loss_fn(output, label)
            loss_meter.update_with_weight(
                loss.item(), label.shape[0])
            top1 = accuracy(output, label[:, 1])[0]
            acc_meter.update_with_weight(top1, label.shape[0])
            result += F.softmax(output, dim=1)[:, 1].tolist()
            labels += label[:, 1].tolist()
        auc = roc_auc_score(labels, result)
        result, labels = np.array(result), np.array(labels)
        result[result > 0.5] = 1
        result[result <= 0.5] = 0
        metric = precision_recall_fscore_support(  #return 精确率、召回率、F1 分数和支持度
            labels, result, average='micro')
        report = classification_report(
            labels, result, output_dict=True, zero_division=0)
        recall = [0, 0]
        for k in report:
            if isfloat(k):
                recall[int(float(k))] = report[k]['recall']
        return [auc] + list(metric) + recall

    def save_attention_weights(self):
        attn_weights = []
        labels = []
        assign_matrices = []
        attn_weights_local = []
        time_matrix=[]
        self.model.eval()
        cont=0
        for time_series, node_feature, label in self.train_dataloader:
            time_series, node_feature, label = time_series.cuda(), node_feature.cuda(), label.cuda()
            [prediction,score], timeseries_tran = self.model(time_series, node_feature)
            timeseries_tran = timeseries_tran.detach().cpu().numpy()
            time_matrix.append(timeseries_tran)
            #prediction, _ = self.model(time_series, node_feature)
            assignMat = self.model.get_assign_mat()
            assign_np = assignMat.detach().cpu().numpy()
            assign_matrices.append(assign_np)
            attn = self.model.get_attention_weights()
            attn_np = attn[0].detach().cpu().numpy()
            label_np = label.detach().cpu().numpy()
            labels.append(label_np)
            attn_weights.append(attn_np)


        for time_series, node_feature, label in self.val_dataloader:
            time_series, node_feature, label = time_series.cuda(), node_feature.cuda(), label.cuda()
            [prediction,score], timeseries_tran = self.model(time_series, node_feature)
            timeseries_tran = timeseries_tran.detach().cpu().numpy()
            time_matrix.append(timeseries_tran)
            #prediction, _ = self.model(time_series, node_feature)
            assignMat = self.model.get_assign_mat()
            assign_np = assignMat.detach().cpu().numpy()
            assign_matrices.append(assign_np)


            attn = self.model.get_attention_weights()
            attn_np = attn[0].detach().cpu().numpy()
            label_np = label.detach().cpu().numpy()
            labels.append(label_np)
            attn_weights.append(attn_np)

        if self.save_test_attn_weights:
            attn_weights_test = []
            labels_test = []
            assign_matrices_test = []

        for time_series, node_feature, label in self.test_dataloader:
            time_series, node_feature, label = time_series.cuda(), node_feature.cuda(), label.cuda()
            [prediction,score], timeseries_tran = self.model(time_series, node_feature)
            timeseries_tran = timeseries_tran.detach().cpu().numpy()
            time_matrix.append(timeseries_tran)
            #prediction, _ = self.model(time_series, node_feature)
            assignMat = self.model.get_assign_mat()
            assign_np = assignMat.detach().cpu().numpy()
            assign_matrices.append(assign_np)


            attn = self.model.get_attention_weights()
            attn_np = attn[0].detach().cpu().numpy()
            label_np = label.detach().cpu().numpy()
            labels.append(label_np)
            attn_weights.append(attn_np)

            if self.save_test_attn_weights:
                assign_matrices_test.append(assign_np)
                labels_test.append(label_np)
                attn_weights_test.append(attn_np)


        np.save(self.save_path/f"attnWeights.npy", attn_weights, allow_pickle=True)
        np.save(self.save_path/f"labels.npy", labels, allow_pickle=True)
        np.save(self.save_path/f"assign_matrices.npy", assign_matrices, allow_pickle=True)
        np.save(self.save_path/f"timeseries_trans.npy", time_matrix, allow_pickle=True)

        if self.save_test_attn_weights:
            np.save(self.save_path/f"attnWeights_test.npy", attn_weights_test, allow_pickle=True)
            np.save(self.save_path/f"labels_test.npy", labels_test, allow_pickle=True)
            np.save(self.save_path/f"assign_matrices_test.npy", assign_matrices_test, allow_pickle=True)

    def generate_save_learnable_matrix(self):

        learable_matrixs = []

        labels = []

        for time_series, node_feature, label in self.test_dataloader:
            label = label.long()
            time_series, node_feature, label = time_series.cuda(), node_feature.cuda(), label.cuda()
            [learable_matrix,score], _ = self.model(time_series, node_feature)
            #learable_matrix, _ = self.model(time_series, node_feature)
            learable_matrixs.append(learable_matrix.cpu().detach().numpy())
            labels += label.tolist()

        self.save_path.mkdir(exist_ok=True, parents=True)
        np.save(self.save_path/"learnable_matrix.npy", {'matrix': np.vstack(
            learable_matrixs), "label": np.array(labels)}, allow_pickle=True)

    def save_result(self, results: torch.Tensor):
        self.save_path.mkdir(exist_ok=True, parents=True)
        np.save(self.save_path/"training_process.npy",
                results, allow_pickle=True)

        torch.save(self.best_model.state_dict(), self.save_path/f"model_{self.best_acc}%.pt")

    def train(self):
        training_process = []
        self.current_step = 0
        best_val_AUC = 0
        best_test_acc = 0
        best_test_AUC = 0
        best_test_sen = 0
        best_test_spec = 0
        for epoch in range(self.epochs):
            self.reset_meters()
            self.train_per_epoch(self.optimizers[0], self.lr_schedulers[0])
            val_result = self.test_per_epoch(self.val_dataloader,
                                             self.val_loss, self.val_accuracy)
            test_result = self.test_per_epoch(self.test_dataloader,
                                              self.test_loss, self.test_accuracy)

            if best_test_acc <= self.test_accuracy.avg:
                best_val_AUC = val_result[0]
                best_test_acc = self.test_accuracy.avg
                self.best_acc=best_test_acc
                best_test_AUC = test_result[0]
                best_test_sen = test_result[-1]
                best_test_spec = test_result[-2]
                wandb.run.summary["Best Test Accuracy"] = self.test_accuracy.avg
                wandb.run.summary["Best Test AUC"] = test_result[0]
                wandb.run.summary["Best Val AUC"] = val_result[0]
                wandb.run.summary["Best Val Accuracy"] = self.val_accuracy.avg
                wandb.run.summary["Best Test Sensitivity"] = test_result[-1]
                wandb.run.summary["Best Test Specificity"] = test_result[-2]
                self.best_model = self.model

            self.logger.info(" | ".join([
                f'Epoch[{epoch}/{self.epochs}]',
                f'Train Loss:{self.train_loss.avg: .3f}',
                f'Train Accuracy:{self.train_accuracy.avg: .3f}%',
                f'Test Loss:{self.test_loss.avg: .3f}',
                f'Test Accuracy:{self.test_accuracy.avg: .3f}%',
                f'Test AUC:{test_result[0]:.4f}',
                f'Val Accuracy:{self.val_accuracy.avg: .3f}',
                f'Val Loss{self.val_loss.avg: .3f}',
                f'Val AUC:{val_result[0]:.4f}',
                f'Test Sen:{test_result[-1]:.4f}',
                f'LR:{self.lr_schedulers[0].lr:.5f}'
            ]))

            wandb.log({
                "Train Loss": self.train_loss.avg,
                "Train Accuracy": self.train_accuracy.avg,
                "Test Loss": self.test_loss.avg,
                "Test Accuracy": self.test_accuracy.avg,
                "Test AUC": test_result[0],
                "Val Loss": self.val_loss.avg,
                "Val Accuracy": self.val_accuracy.avg,
                "Val AUC": val_result[0],
                'Test Sensitivity': test_result[-1],
                'Test Specificity': test_result[-2],
                'micro F1': test_result[-4],
                'micro recall': test_result[-5],
                'micro precision': test_result[-6],
            })

            """if(val_result[0] > best_val_AUC):
                best_val_AUC = val_result[0]
                best_test_acc =  self.test_accuracy.avg
                best_test_AUC =  test_result[0]
                best_test_sen = test_result[-1]
                best_test_spec = test_result[-2]
                wandb.run.summary["Best Test Accuracy"] = self.test_accuracy.avg
                wandb.run.summary["Best Test AUC"] = test_result[0]
                wandb.run.summary["Best Val AUC"] = val_result[0]
                wandb.run.summary["Best Val Accuracy"] = self.val_accuracy.avg
                wandb.run.summary["Best Test Sensitivity"] = test_result[-1]
                wandb.run.summary["Best Test Specificity"] = test_result[-2]"""


            training_process.append({
                "Epoch": epoch,
                "Train Loss": self.train_loss.avg,
                "Train Accuracy": self.train_accuracy.avg,
                "Test Loss": self.test_loss.avg,
                "Test Accuracy": self.test_accuracy.avg,
                "Test AUC": test_result[0],
                'Test Sensitivity': test_result[-1],
                'Test Specificity': test_result[-2],
                'micro F1': test_result[-4],
                'micro recall': test_result[-5],
                'micro precision': test_result[-6],
                "Val AUC": val_result[0],
                "Val Loss": self.val_loss.avg,
                "Val Accuracy": self.val_accuracy.avg,
            })
        if self.save_attn_weights:
            self.save_attention_weights()

        if self.save_learnable_graph:
            self.generate_save_learnable_matrix()

        self.save_result(training_process)
        return best_test_acc,best_test_AUC,best_test_sen,best_test_spec


    def eval(self):
        eval_process = []
        self.current_step = 0
        best_test_acc = 0
        for epoch in range(self.epochs):
            self.reset_meters()
            val_result = self.test_per_epoch(self.val_dataloader,
                                             self.val_loss, self.val_accuracy)
            test_result = self.test_per_epoch(self.test_dataloader,
                                              self.test_loss, self.test_accuracy)

            if best_test_acc <= self.test_accuracy.avg:
                best_test_acc = self.test_accuracy.avg
                self.best_acc=best_test_acc

            self.logger.info(" | ".join([
                f'Epoch[{epoch}/{self.epochs}]',
                f'Test Loss:{self.test_loss.avg: .3f}',
                f'Test Accuracy:{self.test_accuracy.avg: .3f}%',
                f'Test AUC:{test_result[0]:.4f}',
                f'Val Accuracy:{self.val_accuracy.avg: .3f}',
                f'Val Loss{self.val_loss.avg: .3f}',
                f'Val AUC:{val_result[0]:.4f}',
                f'Test Sen:{test_result[-1]:.4f}',
                f'LR:{self.lr_schedulers[0].lr:.5f}'
            ]))

            wandb.log({
                "Test Loss": self.test_loss.avg,
                "Test Accuracy": self.test_accuracy.avg,
                "Test AUC": test_result[0],
                "Val Loss": self.val_loss.avg,
                "Val Accuracy": self.val_accuracy.avg,
                "Val AUC": val_result[0],
                'Test Sensitivity': test_result[-1],
                'Test Specificity': test_result[-2],
                'micro F1': test_result[-4],
                'micro recall': test_result[-5],
                'micro precision': test_result[-6],
            })


            eval_process.append({
                "Epoch": epoch,
                "Test Loss": self.test_loss.avg,
                "Test Accuracy": self.test_accuracy.avg,
                "Test AUC": test_result[0],
                'Test Sensitivity': test_result[-1],
                'Test Specificity': test_result[-2],
                'micro F1': test_result[-4],
                'micro recall': test_result[-5],
                'micro precision': test_result[-6],
                "Val AUC": val_result[0],
                "Val Loss": self.val_loss.avg,
                "Val Accuracy": self.val_accuracy.avg,
            })
        if self.save_attn_weights:
            self.save_attention_weights()

        if self.save_learnable_graph:
            self.generate_save_learnable_matrix()

        self.save_result(eval_process)




def get_timestamp():
    timestampTime = time.strftime("%H%M%S")
    timestampDate = time.strftime("%Y%m%d")
    return timestampDate + "-" + timestampTime


def model_training(cfg: DictConfig,SEED):
    t_accs = []
    t_aucs = []
    t_sens = []
    t_specs = []

    with open_dict(cfg):
        cfg.unique_id = datetime.now().strftime("%m-%d-%H-%M-%S")

    dataloaders = dataset_factory(cfg,SEED)
    for i in range(1):
        logger = logger_factory(cfg)
        model = model_factory(cfg)
        optimizers = optimizers_factory(
            model=model, optimizer_configs=cfg.optimizer)
        lr_schedulers = lr_scheduler_factory(lr_configs=cfg.optimizer,  # 学习率调度器,动态地调整模型的学习率
                                             cfg=cfg)
        data_loder = dataloaders[i]
        training = training_factory(cfg, model, optimizers,
                                    lr_schedulers, data_loder, logger)
        t_acc, t_auc, t_sen, t_spec= training.train()
        t_accs.append(t_acc)
        t_aucs.append(t_auc)
        t_sens.append(t_sen)
        t_specs.append(t_spec)
        #time=time_matrix


    t_accs_mean = np.mean(t_accs)
    t_aucs_mean = np.mean(t_aucs)
    t_sens_mean = np.mean(t_sens)
    t_specs_mean = np.mean(t_specs)
    t_accs_variance = np.std(t_accs)
    t_aucs_variance = np.std(t_aucs)
    t_sens_variance = np.std(t_sens)
    t_specs_variance = np.std(t_specs)
    print(t_accs_variance,t_aucs_variance,t_sens_variance,t_specs_variance)
    print(t_accs_mean, t_aucs_mean,t_sens_mean, t_specs_mean)
    return t_accs, t_aucs, t_sens, t_specs


hydra.main(version_base=None, config_path="conf", config_name="config")
def main(cfg: DictConfig):
    group_name = f"Transformer-{cfg.dataset.batch_size}"
    # num_MHSA 多头数
    count = 0
    acc_list = []
    auc_list = []
    sen_list = []
    spec_list = []
    seeds = list(range(cfg.repeat_time))  # 整个项目重复次数
    for it in range(len(seeds)):
        SEED = seeds[it]
        random.seed(
            SEED
        )  # set the random seed so that the random permutations can be reproduced again
        run = wandb.init(project=cfg.project, group=f"{group_name}", name=f"{group_name}_{get_timestamp()}",
                         reinit=True)

        t_acc, t_auc, t_sen, t_spec = model_training(cfg, SEED)
        acc_list.append(t_acc)
        auc_list.append(t_auc)
        sen_list.append(t_sen)
        spec_list.append(t_spec)
        count = count + 1
        run.finish()
    print("test acc mean:{}  std: {}".format(np.mean(acc_list), np.std(acc_list)))
    print("test auc mean:{}  std: {}".format(np.mean(auc_list), np.std(auc_list)))
    print("test sensitivity mean:{}  std: {}".format(np.mean(sen_list), np.std(sen_list)))
    print("test specficity mean:{}  std: {}".format(np.mean(spec_list), np.std(spec_list)))


if __name__ == '__main__':
    os.environ["CUDA_VISIBLE_DEVICES"] = "1"
    parser = argparse.ArgumentParser()
    parser.add_argument('--config_filename', default='setting/abide_PLSNet.yaml', type=str,
                        help='Configuration filename for training the model.')#用于训练模型的配置文件名。
    parser.add_argument('--repeat_time', default=1, type=int)
    args = parser.parse_args()
    torch.cuda.set_device(0)

    # cudnn.benchmark = False
    cudnn.deterministic = True
    loss_fn = torch.nn.CrossEntropyLoss(reduction='mean')

    with open(args.config_filename) as f:  # setting/abide_PLSNet.yaml
        config = yaml.load(f, Loader=yaml.Loader)
        print(config['data'])

        dataloaders, node_size, node_feature_size, timeseries_size = \
            init_dataloader(config['data'])

        config['train']["seq_len"] = timeseries_size
        config['train']["node_size"] = node_size

        model = PLSNet(config['model'], node_size,
                       node_feature_size, timeseries_size).to(device)
        use_train = BasicTrain

    # 加载训练好的模型权重
    model.load_state_dict(
        torch.load(r'D:\PLSNet-main\result\PLSNet\ABIDE_aal\ 66.502%_09-29-22-47-01\model_66.50246309177042%.pt'))

    # 将模型设置为评估模式
    model.eval()
    train_dataloader, val_dataloader, test_dataloader = dataloaders

    # 定义损失函数，与你训练时一致
    loss_name = 'loss'
    if config['train']["group_loss"]:
        loss_name = f"{loss_name}_group_loss"
    if config['train']["sparsity_loss"]:
        loss_name = f"{loss_name}_sparsity_loss"

    optimizer = torch.optim.Adam(
        model.parameters(), lr=config['train']['lr'],
        weight_decay=config['train']['weight_decay'])
    opts = (optimizer,)

    save_folder_name = Path(config['train']['log_folder']) / Path(config['model']['type']) / Path(
        # date_time +
        f"{config['data']['dataset']}_{config['data']['atlas']}")
    eval_process = use_train(
        config['train'], model, opts, dataloaders, save_folder_name)
    eval_process.eval()

    main()