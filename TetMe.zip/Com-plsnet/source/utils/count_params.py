import torch.nn as nn


def count_params(model: nn.Module, only_requires_grad: bool = False):#段代码计算模型中所有参数的总数量，包括需要梯度更新的参数和不需要梯度更新的参数。
    "count number trainable parameters in a pytorch model"
    if only_requires_grad:
        total_params = sum(p.numel()
                           for p in model.parameters() if p.requires_grad)
    else:
        total_params = sum(p.numel() for p in model.parameters())
    return total_params
