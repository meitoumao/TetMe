from datetime import datetime
import wandb
import hydra
from omegaconf import DictConfig, open_dict
from source.dataset.dataset_fa import dataset_factory
from source.models.model_fa import model_factory
from source.components.fa import lr_scheduler_factory, optimizers_factory, logger_factory
from source.training import training_factory
from datetime import datetime
import os
import time
import numpy as np
import random
import torch
os.environ["WANDB_MODE"] = "offline"

def get_timestamp():
    timestampTime = time.strftime("%H%M%S")
    timestampDate = time.strftime("%Y%m%d")
    return timestampDate + "-" + timestampTime


def reset_wandb_env():
    exclude = {
        "WANDB_PROJECT",
        "WANDB_ENTITY",
        "WANDB_API_KEY",
    }
    #del os.environ["WANDB_RUN_ID"]
    for k, v in os.environ.items():
        if k.startswith("WANDB_RUN_ID") and k not in exclude:
            print(k)
            print(v)
            #os.environ[k]=wandb.util.generate_id()
            


"""def model_training(cfg: DictConfig):
    with open_dict(cfg):
        cfg.unique_id = datetime.now().strftime("%m-%d-%H-%M-%S")
    print(cfg)
    dataloaders = dataset_factory(cfg)
    logger = logger_factory(cfg)
    model = model_factory(cfg)
    optimizers = optimizers_factory(
        model=model, optimizer_configs=cfg.optimizer)
    lr_schedulers = lr_scheduler_factory(lr_configs=cfg.optimizer,#学习率调度器,动态地调整模型的学习率
                                         cfg=cfg)
    training = training_factory(cfg, model, optimizers,
                                lr_schedulers, dataloaders, logger)
    t_acc,t_auc,t_sen,t_spec = training.train()
    return t_acc,t_auc,t_sen,t_spec"""


def model_training(cfg: DictConfig,SEED):
    t_accs = []
    t_aucs = []
    t_sens = []
    t_specs = []
    with open_dict(cfg):
        cfg.unique_id = datetime.now().strftime("%m-%d-%H-%M-%S")

    dataloaders = dataset_factory(cfg, SEED)
    for i in range(5):
        logger = logger_factory(cfg)
        model = model_factory(cfg)
        model.load_state_dict(
            torch.load(r'D:\Com-BrainTF-main\source\result\07-17-12-39-42\model.pt'))
        optimizers = optimizers_factory(
            model=model, optimizer_configs=cfg.optimizer)
        lr_schedulers = lr_scheduler_factory(lr_configs=cfg.optimizer,  # 学习率调度器,动态地调整模型的学习率
                                             cfg=cfg)
        print(len(dataloaders),"ppoooo")
        data_loder = dataloaders[i]
        training = training_factory(cfg, model, optimizers,
                                    lr_schedulers, data_loder, logger)
        training.eval()
        """t_acc, t_auc, t_sen, t_spec = training.eval()
        t_accs.append(t_acc)
        t_aucs.append(t_auc)
        t_sens.append(t_sen)
        t_specs.append(t_spec)"""

    t_accs_mean = np.mean(t_accs)
    t_aucs_mean = np.mean(t_aucs)
    t_sens_mean = np.mean(t_sens)
    t_specs_mean = np.mean(t_specs)
    t_accs_variance = np.std(t_accs)
    t_aucs_variance = np.std(t_aucs)
    t_sens_variance = np.std(t_sens)
    t_specs_variance = np.std(t_specs)
    print(t_accs_variance, t_aucs_variance, t_sens_variance, t_specs_variance)
    print(t_accs_mean, t_aucs_mean, t_sens_mean, t_specs_mean)
    return t_accs, t_aucs, t_sens, t_specs

@hydra.main(version_base=None, config_path="conf", config_name="config")
def main(cfg: DictConfig):
    group_name = f"Transformer-{cfg.dataset.batch_size}"
    #num_MHSA 多头数
    count = 0
    acc_list = []
    auc_list = []
    sen_list = []
    spec_list = []
    seeds = list(range(cfg.repeat_time))#整个项目重复次数
    for it in range(len(seeds)):
        SEED = seeds[it]
        random.seed(
            SEED
        )  # set the random seed so that the random permutations can be reproduced again
        np.random.seed(SEED)
        torch.manual_seed(SEED)
        run = wandb.init(project=cfg.project,group=f"{group_name}", name=f"{group_name}_{get_timestamp()}", reinit=True)

        t_acc,t_auc,t_sen,t_spec = model_training(cfg,SEED)
        acc_list.append(t_acc)
        auc_list.append(t_auc)
        sen_list.append(t_sen)
        spec_list.append(t_spec)
        count = count + 1
        run.finish()
    print("test acc mean:{}  std: {}".format(np.mean(acc_list),np.std(acc_list)))
    print("test auc mean:{}  std: {}".format(np.mean(auc_list),np.std(auc_list)))
    print("test sensitivity mean:{}  std: {}".format(np.mean(sen_list),np.std(sen_list)))
    print("test specficity mean:{}  std: {}".format(np.mean(spec_list),np.std(spec_list)))

if __name__ == '__main__':
    main()
